import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Signup from './pages/Signup';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import ReceiverRequestForm from './pages/ReceiverRequestForm';
import DonorRequestForm from './pages/DonorRequestForm';
import BloodBankAdminPanel from './pages/BloodBankAdminPanel';
import SuperAdminPanel from './pages/SuperAdminPanel';

const App = () => (
  <Router>
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/login" element={<Login />} />
      <Route path="/receiver-request" element={<ReceiverRequestForm />} />
      <Route path="/donor-request" element={<DonorRequestForm />} />
      <Route path="/bloodbank-admin" element={<BloodBankAdminPanel />} />
      <Route path="/superadmin" element={<SuperAdminPanel />} />
    </Routes>
  </Router>
);

export default App;
