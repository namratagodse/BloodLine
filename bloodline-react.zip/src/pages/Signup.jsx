import React, { useState } from 'react';
import { signup } from '../api/auth';
import { useNavigate } from 'react-router-dom';

const Signup = () => {
  const [formData, setFormData] = useState({
    fullName: '', address: '', city: '', state: 'India',
    contactNumber: '', email: '', password: '', role: 'Receiver'
  });

  const navigate = useNavigate();

  const handleChange = e => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await signup(formData);
      alert('Signup successful!');
      navigate('/login');
    } catch {
      alert('Signup failed');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Signup</h2>
      {['fullName', 'address', 'city', 'contactNumber', 'email', 'password'].map((field) => (
        <input key={field} name={field} placeholder={field} type={field === 'password' ? 'password' : 'text'} onChange={handleChange} required />
      ))}
      <select name="role" onChange={handleChange}>
        <option value="Receiver">Receiver</option>
        <option value="Donor">Donor</option>
        <option value="BloodBankAdmin">BloodBankAdmin</option>
      </select>
      <button type="submit">Signup</button>
    </form>
  );
};

export default Signup;
