import React, { useState } from 'react';
import { createBloodRequest } from '../api/bloodRequests';

const ReceiverRequestForm = () => {
  const [formData, setFormData] = useState({
    fullName: '', contactNumber: '', hospitalName: '',
    patientName: '', requiredBloodType: '', bloodBankId: ''
  });

  const handleChange = e => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await createBloodRequest(formData);
      alert('Blood request submitted!');
    } catch {
      alert('Error submitting request');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Raise Blood Request</h2>
      <input name="fullName" placeholder="Full Name" onChange={handleChange} required />
      <input name="contactNumber" placeholder="Contact Number" onChange={handleChange} required />
      <input name="hospitalName" placeholder="Hospital Name" onChange={handleChange} required />
      <input name="patientName" placeholder="Patient Name" onChange={handleChange} required />
      <input name="requiredBloodType" placeholder="Blood Group" onChange={handleChange} required />
      <input name="bloodBankId" placeholder="Nearest Blood Bank ID" onChange={handleChange} required />
      <button type="submit">Submit Request</button>
    </form>
  );
};

export default ReceiverRequestForm;
