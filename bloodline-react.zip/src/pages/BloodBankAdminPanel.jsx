import React from 'react';

const BloodBankAdminPanel = () => {
  return (
    <div>
      <h2>Blood Bank Admin Panel</h2>
      <p>Manage requests, donations, and monitor inventory.</p>
    </div>
  );
};

export default BloodBankAdminPanel;
