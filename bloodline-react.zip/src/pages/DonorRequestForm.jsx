import React, { useState } from 'react';
import { donateBlood } from '../api/donations';

const DonorRequestForm = () => {
  const [formData, setFormData] = useState({
    donatedBloodType: '', units: '', bloodBankId: ''
  });

  const handleChange = e => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await donateBlood(formData);
      alert('Donation request submitted!');
    } catch {
      alert('Error submitting donation');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Blood Donation Form</h2>
      <input name="donatedBloodType" placeholder="Blood Type" onChange={handleChange} required />
      <input name="units" type="number" placeholder="Units" onChange={handleChange} required />
      <input name="bloodBankId" placeholder="Blood Bank ID" onChange={handleChange} required />
      <button type="submit">Donate</button>
    </form>
  );
};

export default DonorRequestForm;
