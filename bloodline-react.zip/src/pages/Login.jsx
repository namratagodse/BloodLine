import React, { useState } from 'react';
import { login } from '../api/auth';
import { useNavigate } from 'react-router-dom';
import jwt_decode from 'jwt-decode';

const Login = () => {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const navigate = useNavigate();

  const handleChange = e => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      const res = await login(formData);
      const token = res.data.token;
      localStorage.setItem('token', token);

      const decoded = jwt_decode(token);
      const role = decoded?.role;

      if (role === 'Receiver') navigate('/receiver-request');
      else if (role === 'Donor') navigate('/donor-request');
      else if (role === 'BloodBankAdmin') navigate('/bloodbank-admin');
      else if (role === 'SuperAdmin') navigate('/superadmin');
    } catch {
      alert('Login failed');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Login</h2>
      <input name="email" placeholder="Email" onChange={handleChange} required />
      <input type="password" name="password" placeholder="Password" onChange={handleChange} required />
      <button type="submit">Login</button>
    </form>
  );
};

export default Login;
