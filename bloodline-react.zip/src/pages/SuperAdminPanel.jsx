import React from 'react';

const SuperAdminPanel = () => {
  return (
    <div>
      <h2>Super Admin Dashboard</h2>
      <p>View all users, blood banks, and oversee nationwide data.</p>
    </div>
  );
};

export default SuperAdminPanel;
