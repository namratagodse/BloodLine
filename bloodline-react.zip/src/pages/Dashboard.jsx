import React from 'react';
import { Link } from 'react-router-dom';

const Dashboard = () => (
  <div>
    <h2>Welcome to BloodLine</h2>
    <p>Select an action below:</p>
    <Link to="/signup">Signup</Link> | <Link to="/login">Login</Link>
  </div>
);

export default Dashboard;
