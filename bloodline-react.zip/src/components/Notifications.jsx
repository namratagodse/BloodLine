import React from 'react';

const Notifications = ({ messages }) => {
  return (
    <div>
      <h4>Notifications</h4>
      <ul>
        {messages.map((msg, index) => <li key={index}>{msg}</li>)}
      </ul>
    </div>
  );
};

export default Notifications;
