import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const logout = () => {
    localStorage.removeItem('token');
    window.location.href = '/';
  };

  return (
    <nav>
      <Link to="/">Home</Link> | <Link to="/receiver-request">Request Blood</Link> | <Link to="/donor-request">Donate</Link>
      <button onClick={logout} style={{ float: 'right' }}>Logout</button>
    </nav>
  );
};

export default Navbar;
