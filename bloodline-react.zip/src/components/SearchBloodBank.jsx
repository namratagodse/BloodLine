import React from 'react';

const SearchBloodBank = () => {
  return (
    <div>
      <h3>Search Nearest Blood Bank</h3>
      <input placeholder="Enter City or Area" />
      <button>Search</button>
    </div>
  );
};

export default SearchBloodBank;
