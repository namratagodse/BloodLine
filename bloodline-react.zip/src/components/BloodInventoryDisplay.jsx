import React from 'react';

const BloodInventoryDisplay = ({ inventory }) => {
  return (
    <div>
      <h3>Blood Inventory</h3>
      {inventory ? (
        <ul>
          {Object.entries(inventory).map(([type, units]) => (
            <li key={type}>{type}: {units} units</li>
          ))}
        </ul>
      ) : <p>No inventory data</p>}
    </div>
  );
};

export default BloodInventoryDisplay;
