// TODO: Implement BloodInventoryDisplay component or API
