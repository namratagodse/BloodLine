// TODO: Implement Navbar component or API
