// TODO: Implement auth component or API
