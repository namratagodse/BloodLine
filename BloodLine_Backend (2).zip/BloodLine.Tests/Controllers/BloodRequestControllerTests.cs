// Auto-generated stub for BloodRequestControllerTests.cs
// You can replace this with full class implementation.
