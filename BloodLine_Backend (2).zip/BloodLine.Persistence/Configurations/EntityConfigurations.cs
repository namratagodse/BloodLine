// Auto-generated stub for EntityConfigurations.cs
// You can replace this with full class implementation.
