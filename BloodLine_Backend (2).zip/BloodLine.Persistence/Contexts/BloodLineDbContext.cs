// Auto-generated stub for BloodLineDbContext.cs
// You can replace this with full class implementation.
