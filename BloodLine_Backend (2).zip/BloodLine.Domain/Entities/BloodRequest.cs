// Auto-generated stub for BloodRequest.cs
// You can replace this with full class implementation.
