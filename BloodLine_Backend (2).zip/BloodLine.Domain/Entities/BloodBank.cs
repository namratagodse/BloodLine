// Auto-generated stub for BloodBank.cs
// You can replace this with full class implementation.
