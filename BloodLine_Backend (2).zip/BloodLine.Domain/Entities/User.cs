// Auto-generated stub for User.cs
// You can replace this with full class implementation.
