// Auto-generated stub for BloodType.cs
// You can replace this with full class implementation.
