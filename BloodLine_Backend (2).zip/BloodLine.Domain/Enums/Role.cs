// Auto-generated stub for Role.cs
// You can replace this with full class implementation.
