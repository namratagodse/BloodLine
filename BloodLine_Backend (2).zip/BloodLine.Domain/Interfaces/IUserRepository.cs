// Auto-generated stub for IUserRepository.cs
// You can replace this with full class implementation.
