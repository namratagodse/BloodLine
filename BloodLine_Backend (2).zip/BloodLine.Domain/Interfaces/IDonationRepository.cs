// Auto-generated stub for IDonationRepository.cs
// You can replace this with full class implementation.
