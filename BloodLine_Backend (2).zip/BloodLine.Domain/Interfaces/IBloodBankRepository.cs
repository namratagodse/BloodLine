// Auto-generated stub for IBloodBankRepository.cs
// You can replace this with full class implementation.
