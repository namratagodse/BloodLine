using Microsoft.Extensions.Logging;

namespace BloodLine.Infrastructure.Geo
{
    public class GeoLocationService : IGeoLocationService
    {
        private readonly ILogger<GeoLocationService> _logger;

        public GeoLocationService(ILogger<GeoLocationService> logger)
        {
            _logger = logger;
        }

        public Task<IEnumerable<string>> FindNearbyBloodBanksAsync(string city)
        {
            _logger.LogInformation($"Searching for blood banks near {city}...");
            var dummyData = new List<string>
            {
                $"{city} Blood Bank 1",
                $"{city} Blood Bank 2",
                $"{city} Blood Bank 3"
            };
            return Task.FromResult(dummyData.AsEnumerable());
        }
    }
}
