namespace BloodLine.Infrastructure.Geo
{
    public interface IGeoLocationService
    {
        Task<IEnumerable<string>> FindNearbyBloodBanksAsync(string city);
    }
}
