// Auto-generated stub for IEmailService.cs
// You can replace this with full class implementation.
