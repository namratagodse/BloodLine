// Auto-generated stub for ISmsService.cs
// You can replace this with full class implementation.
