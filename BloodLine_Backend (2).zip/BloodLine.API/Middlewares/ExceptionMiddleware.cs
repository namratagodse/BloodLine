// Auto-generated stub for ExceptionMiddleware.cs
// You can replace this with full class implementation.
