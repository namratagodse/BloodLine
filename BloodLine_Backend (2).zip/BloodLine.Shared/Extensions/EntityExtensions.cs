// Auto-generated stub for EntityExtensions.cs
// You can replace this with full class implementation.
