// Auto-generated stub for DtoMapper.cs
// You can replace this with full class implementation.
