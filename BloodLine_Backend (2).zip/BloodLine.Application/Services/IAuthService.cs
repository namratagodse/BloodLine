using BloodLine.Application.DTOs;

namespace BloodLine.Application.Services
{
    public interface IAuthService
    {
        Task<string> SignupAsync(SignupDto dto);
        Task<string> LoginAsync(string email, string password);
    }
}
