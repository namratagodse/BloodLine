// Auto-generated stub for IDonationService.cs
// You can replace this with full class implementation.
