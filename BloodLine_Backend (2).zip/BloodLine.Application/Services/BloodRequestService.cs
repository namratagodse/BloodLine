// Auto-generated stub for BloodRequestService.cs
// You can replace this with full class implementation.
