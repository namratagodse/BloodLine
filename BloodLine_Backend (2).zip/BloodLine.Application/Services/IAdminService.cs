// Auto-generated stub for IAdminService.cs
// You can replace this with full class implementation.
