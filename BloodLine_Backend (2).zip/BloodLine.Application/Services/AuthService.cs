using BloodLine.Application.DTOs;
using BloodLine.Domain.Entities;
using BloodLine.Domain.Enums;
using BloodLine.Domain.Interfaces;
using BloodLine.Application.Helpers;
using Microsoft.AspNetCore.Identity;

namespace BloodLine.Application.Services
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepo;
        private readonly JwtHelper _jwt;

        public AuthService(IUserRepository userRepo, JwtHelper jwt)
        {
            _userRepo = userRepo;
            _jwt = jwt;
        }

        public async Task<string> SignupAsync(SignupDto dto)
        {
            var exists = await _userRepo.GetByEmailAsync(dto.Email);
            if (exists != null) throw new Exception("Email already registered");

            var user = new User
            {
                Id = Guid.NewGuid(),
                FullName = dto.FullName,
                Address = dto.Address,
                City = dto.City,
                State = dto.State,
                ContactNumber = dto.ContactNumber,
                Email = dto.Email,
                Role = dto.Role,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password)
            };

            await _userRepo.AddAsync(user);
            return "User registered successfully";
        }

        public async Task<string> LoginAsync(string email, string password)
        {
            var user = await _userRepo.GetByEmailAsync(email);
            if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
                throw new Exception("Invalid credentials");

            return _jwt.GenerateJwtToken(user);
        }
    }
}
