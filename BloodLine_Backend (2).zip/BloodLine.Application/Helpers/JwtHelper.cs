// Auto-generated stub for JwtHelper.cs
// You can replace this with full class implementation.
