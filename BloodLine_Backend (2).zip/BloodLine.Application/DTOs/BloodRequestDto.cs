using BloodLine.Domain.Enums;

namespace BloodLine.Application.DTOs
{
    public class BloodRequestDto
    {
        public string FullName { get; set; }
        public string ContactNumber { get; set; }
        public string HospitalName { get; set; }
        public string PatientName { get; set; }
        public BloodType RequiredBloodType { get; set; }
        public Guid BloodBankId { get; set; }
    }
}
