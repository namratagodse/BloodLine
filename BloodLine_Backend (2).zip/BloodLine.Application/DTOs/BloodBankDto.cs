namespace BloodLine.Application.DTOs
{
    public class BloodBankDto
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public Dictionary<string, int> Inventory { get; set; }
    }
}
