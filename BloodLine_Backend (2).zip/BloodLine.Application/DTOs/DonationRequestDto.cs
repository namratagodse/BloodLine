using BloodLine.Domain.Enums;

namespace BloodLine.Application.DTOs
{
    public class DonationRequestDto
    {
        public BloodType DonatedBloodType { get; set; }
        public int Units { get; set; }
        public Guid BloodBankId { get; set; }
    }
}
